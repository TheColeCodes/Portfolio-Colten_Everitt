using System.Collections;
				using System.Collections.Generic;
				using UnityEngine;
				using UnityEngine.UI;
	
				public class IndexFiller : MonoBehaviour {
					void Start () {
					uni.objSrch ("apiTextField").GetComponent<Text> ().text = Polymorpher_API.pullsetFuel();
uni.objSrch ("apiDesc").GetComponent<Text> ().text = Polymorpher_API.pullsetFuelDesc();
					}
				}
