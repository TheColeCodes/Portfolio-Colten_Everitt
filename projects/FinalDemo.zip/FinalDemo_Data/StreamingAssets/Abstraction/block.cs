using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class block : MonoBehaviour {
 //use for initialization
public GameObject arr; 
public bool check;
void Start(){
 	 check = false;
 }
  
 // Update is called once per frame
 void Update () {
if (check == false)
{
transform.position = new Vector3 (0,0,0);

}

}

}

