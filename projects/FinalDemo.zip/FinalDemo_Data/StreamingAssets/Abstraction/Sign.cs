using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sign {
bool check = false; 

public void signScript (GameObject plant)
{
plant.transform.position = new Vector2 (0,0);
}

}




