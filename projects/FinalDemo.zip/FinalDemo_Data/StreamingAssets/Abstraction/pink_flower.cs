using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pink_flower : MonoBehaviour {
	bool check = true;
	bool Movercheck = false;
	bool Arrowcheck = false;
public GameObject plantManager;

//Use this for initialization
	void Start () {

		transform.position = new Vector2(34f,-38);	
	}
	
	// Update is called once per frame
	void Update () 
{
plantManager = GameObject.Find ("PlantInventoryController");
if (plantManager.GetComponent<PlantInventoryControllerScript> ().hasOGpurplePlant == true )
{
transform.position = new
Vector2(transform.position.x, transform.position.y-.11f);
}
	}
/*
void Update () {
if (check) {
		//Call mover first
		if (Movercheck == false) {
			//MAKE CHANGES HERE
			Movercheck = AbstractionHelperFuncs.transformMover (-56.48f, 4.22f, this.gameObject);
		}
		//Call stop arrow function 
		if (Arrowcheck == false) {
			//MAKE CHANGES HERE
			Arrowcheck = AbstractionHelperFuncs.stopArrows (0);
		}

check = false;	
}

}

	
//COMMENT HERE
*/
}




























































































