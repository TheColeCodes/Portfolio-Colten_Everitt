using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class yellow_flower : MonoBehaviour {
	//DO NOT REMOVE. CAN CAUSE UNPREDICTABLE BEHAVIOR
	bool Movercheck = false;
	bool Arrowcheck = false;
	bool check = true;
	int timer =0;
	GameObject plantManager;

	void Start() 
	{
		transform.position = new Vector2 (-70, -50);

	}

	void Update()
	{
		plantManager = GameObject.Find ("PlantInventoryController");
		if(true) {
		

			timer++;
			if (timer == 45)
				transform.position = new Vector2 (-60, -50);
		}
	}
/*


	void Update () {
		if (check) {
			//Call mover first
			if (Movercheck == false) {
				//MAKE CHANGES HERE
				Movercheck = AbstractionHelperFuncs.transformMover (-56.48f, 4.22f, this.gameObject);
			}
			//Call stop arrow function 
			if (Arrowcheck == false) {
				//MAKE CHANGES HERE
				Arrowcheck = AbstractionHelperFuncs.stopArrows (0);
			}

			check = false;	
		}

	}

	//COMMENT HERE
*/
}


























