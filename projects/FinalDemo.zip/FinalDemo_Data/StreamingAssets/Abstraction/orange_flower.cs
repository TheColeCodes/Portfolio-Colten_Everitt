using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class orange_flower : MonoBehaviour {
	//DO NOT REMOVE. CAN CAUSE UNPREDICTABLE BEHAVIOR
	bool Movercheck=false;
	bool Arrowcheck = false;
	bool check= true; 


	void Start()
	{
		transform.position = new Vector2 (30.5f, 1);

	}
/*
	

void Update () {
if (check) {
		//Call mover first
		if (Movercheck == false) {
			//MAKE CHANGES HERE
			Movercheck = AbstractionHelperFuncs.transformMover (-56.48f, 4.22f, this.gameObject);
		}
		//Call stop arrow function 
		if (Arrowcheck == false) {
			//MAKE CHANGES HERE
			Arrowcheck = AbstractionHelperFuncs.stopArrows (0);
		}

check = false;	
}

}
	
*/		
}
	








































