using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blockWooden : MonoBehaviour {
	private float weight = 1;

	void Update () {
		GetComponent<Rigidbody2D> ().mass = weight;
	}
}



