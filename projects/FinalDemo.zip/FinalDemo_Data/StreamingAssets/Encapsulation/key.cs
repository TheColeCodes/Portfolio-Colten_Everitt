using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class key : MonoBehaviour {

	public bool carried = false;
	public GameObject Player;
	public int combination = 123456;

	void Update () {
		if (carried) {
			transform.position = new Vector3 (Player.transform.position.x, Player.transform.position.y, Player.transform.position.z - .1f);
			transform.rotation = Quaternion.identity;
		}
	}

	void OnCollisionEnter2D(Collision2D other){
		if (other.gameObject.tag == "Player") {
			gameObject.GetComponent<BoxCollider2D> ().isTrigger = true;
			gameObject.GetComponent<Rigidbody2D> ().gravityScale = 0;
			carried = true;
			print ("This happened");
			Player = other.gameObject;
		}
	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag == "Gate") {
			Destroy (other.gameObject);
			Destroy (gameObject);
		}
	}
}



















