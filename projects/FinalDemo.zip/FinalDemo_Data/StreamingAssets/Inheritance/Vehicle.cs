using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour {


	//Vehicle Part Slots (DO NOT ALTER):
	GameObject leftSpoke; //The left spoke on the bottom of the vehicle
	GameObject rightSpoke; //The right spoke on the bottom of the vehicle
	GameObject centerBeam; //The central beam on top of the vehicle
	GameObject deckFront; //The front end of the main vehicle deck
	GameObject deckBack; //The back end of the main vehicle deck
	//end of part slot declaration

	

	// Use this for initialization
	void Start () {
		//Assign vehicle part slots their positions(DO NOT ALTER)
		leftSpoke = uni.objSrch("leftSpoke");
		rightSpoke = uni.objSrch("rightSpoke");
		centerBeam = uni.objSrch("centerBeam");
		deckFront = uni.objSrch("deckFront");
		deckBack = uni.objSrch("deckBack");
		//end of part slot assignment

		//class declaration and use example
		VehicleClass v = new VehicleClass();
		v.addWheel (leftSpoke, "small");
		v.addWheel (rightSpoke, "small");
		v.addProp(centerBeam);

		v.addEngine(deckBack, "small");
		v.setFuel(300);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}























































