using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bit : MonoBehaviour {

	// Use this for initialization
bool check = false;
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
//Use this in your Update() function!

if(!check) { 
	transform.position = new Vector2(7, 7); 
	 check = true; 
	}


}



}









