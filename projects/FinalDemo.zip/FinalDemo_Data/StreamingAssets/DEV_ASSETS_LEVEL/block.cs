using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class block : MonoBehaviour {
	
	//use for initialization
	void Start(){
		helpme.initialize(script);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

