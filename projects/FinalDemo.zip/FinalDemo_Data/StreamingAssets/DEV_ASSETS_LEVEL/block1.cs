using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class block1 : MonoBehaviour {
	
	//use for initialization
	void Start(){
		
	}
	
	// Update is called once per frame
	void Update () {
transform.position = new Vector2 (0,0);
		
	}
}



