﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blockRO2 : MonoBehaviour {

	//THIS IS A READ ONLY SCRIPT
}
