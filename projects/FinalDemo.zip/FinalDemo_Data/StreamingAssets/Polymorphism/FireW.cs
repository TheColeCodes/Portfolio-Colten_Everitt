using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireW : MoveableAffector
{
	public override void Move()
	{
	
		//Spells.MoveX(Spells.Time(), This);
		Spells.ScaleYTo(6.0f, This);
	}
	
    public override void Affect(GameObject other)
    {
		Box b = other.GetComponent<Box>();

		b.Burn();
	}
}












































