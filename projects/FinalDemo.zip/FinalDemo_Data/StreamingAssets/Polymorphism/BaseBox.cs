﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
*****************************************
Representation of the Box abstract class
*****************************************
*/
public abstract class BaseBox : MonoBehaviour 
{
	protected Rigidbody2D BoxRigidbody;
	protected bool IsFrozen;
	
	protected GameObject This;
	// Use this for initialization
	void Start () 
	{
		BoxRigidbody = GetComponent<Rigidbody2D>();
		IsFrozen = false;
		This = this.gameObject;
	}
	
	public abstract void Burn();

	public abstract void Freeze();
}
