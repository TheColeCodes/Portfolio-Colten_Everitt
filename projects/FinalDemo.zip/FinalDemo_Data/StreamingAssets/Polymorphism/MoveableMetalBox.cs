using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveableMetalBox : Moveable
{
	public override void Move()
	{
		Spells.MoveY(Spells.Time(), This);
	}
}






