using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IceW : MoveableAffector
{   

    public override void Move()
    {
		
        //Try moving it on the x-axis
		Spells.MoveX(Spells.Time(), This);
    }

    public override void Affect(GameObject other)
    {
		Box b = other.GetComponent<Box>();
	    b.Freeze();
    }
}


